﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGui
{
     class Collision 
    {
        public static bool PlayerCollisionWithPallet(GameCell nextCell)
        {
            if (nextCell == null)
            {
                return false;
            }
            if (nextCell.currentGameObject == null)
            {
                return false;
            }
            if ( nextCell.currentGameObject.Type == GameObjectType.REWARD)
            {
                return true;
            }
            return false;
        }
        public static bool PlayerCollisionWithGhost(GameCell nextCell)
        {
            if (nextCell == null)
            {
                return false;
            }
            if (nextCell.currentGameObject == null)
            {
                return false;
            }
            if (nextCell.currentGameObject.Type == GameObjectType.ENEMY)
            {
               
                return true;

            }
           
            return false;
        }
        public static bool PlayerCollisionWithGhost(GameObject obj1, GameObject obj2)
        {
            if (obj1.CurrentCell.X == obj2.CurrentCell.X && obj1.CurrentCell.Y == obj2.CurrentCell.Y)
            {

                return true;

            }

            return false;
        }
    }
}
