﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PacmanGui
{
     class RandomGhost : Ghost
    {
        //public static GameDirection direction = GameDirection.UP;
        /* public RandomGhost(char Character, GameCell c) : base(Character, c)
         {
             CurrentCell = c;
             DisplayCharacter = Character;
         }*/
        public RandomGhost(Image image, GameCell c) : base(image, c)
        {
            this.CurrentCell = c;
           
        }
        public Random ghostDirection() 
        {
            Random rad = new Random();
            return rad;
            
        }
        public override GameCell Move()
        {
            if (previousObject == GameObjectType.REWARD)
            {
                CurrentCell.setGameObject(Game.GetRewardGameObject());
              
            }
            else if (previousObject == GameObjectType.NONE)
            {
                CurrentCell.setGameObject(Game.GetBlankGameObject());
            }
            Random rand = ghostDirection();
            GameCell currentCell = this.CurrentCell;
            GameCell nextCell = currentCell.nextCell(GameDirection.LEFT);
            if (nextCell.currentGameObject.Type == GameObjectType.REWARD)
            {
                previousObject = GameObjectType.REWARD;

            }
            else if (nextCell.currentGameObject.Type== GameObjectType.NONE)
            {
                previousObject = GameObjectType.NONE;
            }
            this.CurrentCell = nextCell;
            nextCell.setGameObject(this);
            if(currentCell!= nextCell)
            {
                currentCell.setGameObject(Game.GetBlankGameObject());

            }
            else
            {
                currentCell.X = rand.Next(10, 20);
                currentCell.Y = rand.Next(10,20);

            }
            return nextCell;


        }
    }
}
