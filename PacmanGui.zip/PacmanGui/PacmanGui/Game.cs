﻿using PacmanGui.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGui
{
     class Game
    {
        public static GameObject GetBlankGameObject()
        {
            GameObject BlankGameObject = new GameObject(Resources.simplebox,GameObjectType.NONE);
            return BlankGameObject;
        }
        public static GameObject GetRewardGameObject()
        {
            GameObject RewardObject = new GameObject(Resources.pallet, GameObjectType.REWARD);
            return RewardObject;
        }
        public static Image getGameObjetcImage(char displayCharacter)
        {
            Image image = PacmanGui.Properties.Resources.simplebox;
            if (displayCharacter == '|' || displayCharacter == '%')
            {
                image = PacmanGui.Properties.Resources.vertical;
                return image;
            }
            else if (displayCharacter == '.')
            {
                image = PacmanGui.Properties.Resources.pallet;
                return image;
            }
            return null;
        }
    }
}
