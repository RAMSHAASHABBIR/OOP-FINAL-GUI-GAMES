﻿namespace SnowBrosGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.TxtScore = new System.Windows.Forms.Label();
            this.TxtPrintScore = new System.Windows.Forms.TextBox();
            this.LblLives = new System.Windows.Forms.Label();
            this.TxtPrintLives = new System.Windows.Forms.TextBox();
            this.lblenemycount = new System.Windows.Forms.Label();
            this.txtenemycount = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // GameTimer
            // 
            this.GameTimer.Enabled = true;
            this.GameTimer.Tick += new System.EventHandler(this.GameTimer_Tick);
            // 
            // TxtScore
            // 
            this.TxtScore.AutoSize = true;
            this.TxtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.TxtScore.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.TxtScore.Location = new System.Drawing.Point(90, 399);
            this.TxtScore.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TxtScore.Name = "TxtScore";
            this.TxtScore.Size = new System.Drawing.Size(74, 22);
            this.TxtScore.TabIndex = 1;
            this.TxtScore.Text = "SCORE";
            this.TxtScore.Click += new System.EventHandler(this.TxtScore_Click);
            // 
            // TxtPrintScore
            // 
            this.TxtPrintScore.Location = new System.Drawing.Point(184, 401);
            this.TxtPrintScore.Margin = new System.Windows.Forms.Padding(2);
            this.TxtPrintScore.Name = "TxtPrintScore";
            this.TxtPrintScore.ReadOnly = true;
            this.TxtPrintScore.Size = new System.Drawing.Size(66, 20);
            this.TxtPrintScore.TabIndex = 2;
            this.TxtPrintScore.Visible = false;
            this.TxtPrintScore.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // LblLives
            // 
            this.LblLives.AutoSize = true;
            this.LblLives.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.LblLives.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LblLives.Location = new System.Drawing.Point(553, 401);
            this.LblLives.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblLives.Name = "LblLives";
            this.LblLives.Size = new System.Drawing.Size(60, 22);
            this.LblLives.TabIndex = 3;
            this.LblLives.Text = "LIVES";
            // 
            // TxtPrintLives
            // 
            this.TxtPrintLives.Location = new System.Drawing.Point(648, 401);
            this.TxtPrintLives.Margin = new System.Windows.Forms.Padding(2);
            this.TxtPrintLives.Name = "TxtPrintLives";
            this.TxtPrintLives.ReadOnly = true;
            this.TxtPrintLives.Size = new System.Drawing.Size(66, 20);
            this.TxtPrintLives.TabIndex = 4;
            this.TxtPrintLives.Visible = false;
            // 
            // lblenemycount
            // 
            this.lblenemycount.AutoSize = true;
            this.lblenemycount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.lblenemycount.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblenemycount.Location = new System.Drawing.Point(299, 399);
            this.lblenemycount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblenemycount.Name = "lblenemycount";
            this.lblenemycount.Size = new System.Drawing.Size(89, 22);
            this.lblenemycount.TabIndex = 5;
            this.lblenemycount.Text = "ENEMIES";
            // 
            // txtenemycount
            // 
            this.txtenemycount.Location = new System.Drawing.Point(411, 399);
            this.txtenemycount.Margin = new System.Windows.Forms.Padding(2);
            this.txtenemycount.Name = "txtenemycount";
            this.txtenemycount.ReadOnly = true;
            this.txtenemycount.Size = new System.Drawing.Size(66, 20);
            this.txtenemycount.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(853, 455);
            this.Controls.Add(this.txtenemycount);
            this.Controls.Add(this.lblenemycount);
            this.Controls.Add(this.TxtPrintLives);
            this.Controls.Add(this.LblLives);
            this.Controls.Add(this.TxtPrintScore);
            this.Controls.Add(this.TxtScore);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.Label TxtScore;
        private System.Windows.Forms.TextBox TxtPrintScore;
        private System.Windows.Forms.Label LblLives;
        private System.Windows.Forms.TextBox TxtPrintLives;
        private System.Windows.Forms.Label lblenemycount;
        private System.Windows.Forms.TextBox txtenemycount;
    }
}

