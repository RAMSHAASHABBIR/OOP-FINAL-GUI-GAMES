﻿namespace SnowBrosGame
{
    partial class FormEndGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblgameover = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblgameover
            // 
            this.lblgameover.AutoSize = true;
            this.lblgameover.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F);
            this.lblgameover.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblgameover.Location = new System.Drawing.Point(217, 104);
            this.lblgameover.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.lblgameover.Name = "lblgameover";
            this.lblgameover.Size = new System.Drawing.Size(353, 63);
            this.lblgameover.TabIndex = 0;
            this.lblgameover.Text = "GAME OVER";
            this.lblgameover.Click += new System.EventHandler(this.lblgameover_Click);
            // 
            // FormEndGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblgameover);
            this.Name = "FormEndGame";
            this.Text = "FormEndGame";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormEndGame_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblgameover;
    }
}