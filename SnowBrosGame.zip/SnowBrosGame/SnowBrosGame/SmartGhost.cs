﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
     class SmartGhost : Ghost
    {
        public GameObject snowbros;

        public GameDirection direction = GameDirection.LEFT;
        public SmartGhost(Image image, GameCell CurrentCell, GameObject player) : base(GameObjectType.ENEMY, image)
        {
            snowbros = player;
            this.CurrentCell = CurrentCell; 
        }
        public override GameCell Move()
        {
			if (previousObject == GameObjectType.REWARD)
			{
				CurrentCell.SetGameObject(Game.GetRewardGameObject());
			}
			else if (previousObject == GameObjectType.NONE)
			{
				CurrentCell.SetGameObject(Game.GetBlankGameObject());
			}
			GameCell currentCell = CurrentCell;
            GameCell Cell1 = currentCell.NextCell(GameDirection.UP);
            GameCell Cell2 = currentCell.NextCell(GameDirection.DOWN);
            GameCell Cell3 = currentCell.NextCell(GameDirection.LEFT);
            GameCell Cell4 = currentCell.NextCell(GameDirection.RIGHT);
            double Up = GameGrid.Get_Distance(Cell1, snowbros.currentCell);
            double Down = GameGrid.Get_Distance(Cell2, snowbros.currentCell);
            double Left = GameGrid.Get_Distance(Cell3, snowbros.currentCell);
            double Right = GameGrid.Get_Distance(Cell4, snowbros.currentCell);
           
            if (Right < Down && Right < Left && Right < Up)
            {
                setPrev(Cell4);
                CurrentCell = Cell4;
                return Cell4;
            }
            else if (Down < Up && Down < Left && Down < Right)
            {
              
                setPrev(Cell2);
                CurrentCell = Cell2;
                return Cell2;
            }
            else if (Left < Right && Left < Up && Left < Down)
            {
                setPrev(Cell3);
                CurrentCell = Cell3;
                return Cell3;
            }
            else
            {
                setPrev(Cell1);
                CurrentCell = Cell1;
                return Cell1;
            }
        }
        void setPrev(GameCell nextCell)
        {
			if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.REWARD)
			{
				previousObject = GameObjectType.REWARD;
			}
			else if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.NONE)
			{
				previousObject = GameObjectType.NONE;
			}
		}
    }
}
