﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Security.Cryptography.X509Certificates;

namespace SnowBrosGame
{
     class RandomGhost : Ghost
    {
        GameDirection direction;
        public RandomGhost(Image image, GameCell CurrentCell) : base(GameObjectType.ENEMY, image)
        {
            this.CurrentCell = CurrentCell;
        }
        private GameDirection GetDirection()
        {
            GameDirection randomDirection;
            Random rand = new Random();
            int number = rand.Next(1, 12);
            if (number == 1 || number == 2 || number == 3)
                randomDirection = GameDirection.UP;
            else if (number == 4 || number == 5 || number == 6)
                randomDirection = GameDirection.DOWN;
            else if (number == 7 || number == 8 || number == 9)
                randomDirection = GameDirection.LEFT;
            else
                randomDirection = GameDirection.RIGHT;

            return randomDirection;
        }
        public override GameCell Move()
        {
            if (previousObject== GameObjectType.REWARD)
            {
                CurrentCell.SetGameObject(Game.GetRewardGameObject());
            }
            else if (previousObject== GameObjectType.NONE)
            {
                CurrentCell.SetGameObject(Game.GetBlankGameObject());
            }
            GameCell currentCell = CurrentCell;
            GameCell nextCell = null;
            while (nextCell == null)
            {
                GameDirection random = GetDirection();
                nextCell = currentCell.NextCell(random);
				if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.REWARD)
				{
					previousObject = GameObjectType.REWARD;
				}
				else if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.NONE)
				{
					previousObject = GameObjectType.NONE;
				}
				CurrentCell = nextCell;
              
            }
            return nextCell;
        }
       
    }
}
