﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Diagnostics.Eventing.Reader;

namespace SnowBrosGame
{
    class Shooting : GameObject
    {
        GameDirection direction;
        public Shooting(Image image,GameCell Currentcell,GameDirection direction): base (GameObjectType.ENEMY,image)
        { 
            this.direction = direction;
        }
        public string move()  
        {
            currentCell.SetGameObject(Game.GetBlankGameObject());
            GameCell nextcell = currentCell.NextCell(direction);
           if(currentCell == nextcell)
             {
                 this.currentCell.SetGameObject(Game.GetBlankGameObject());
                return "W";
            }
            if(nextcell.CurrentGameObject.gameObjectType == GameObjectType.ENEMY)
            {
                CurrentCell = nextcell;
                currentCell.SetGameObject(Game.GetBlankGameObject());
                return "E";
            }
			CurrentCell = nextcell;
            return "none";
        } 
    }
}
 