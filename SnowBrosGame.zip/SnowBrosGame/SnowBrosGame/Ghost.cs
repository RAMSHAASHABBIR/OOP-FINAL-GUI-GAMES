﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
     abstract class Ghost : GameObject
    {
        public static int ghostdecreasehealth = 7;
        public GameObjectType previousObject = GameObjectType.NONE;
        public Ghost(GameObjectType type, Image displayImage) : base(type, displayImage)
        {
        }
        public abstract GameCell Move();
    }
}
 