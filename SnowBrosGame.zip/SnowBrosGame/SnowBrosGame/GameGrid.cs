﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
    class GameGrid
    {
        public GameCell[,] GameCells;
        public int rows;
        public int cols;
        public GameGrid(string fileName, int rows, int cols)
        {  
            this.rows = rows;
            this.cols = cols;
            GameCells = new GameCell[rows, cols];
            LoadGrid(fileName);
        }
        private void LoadGrid(string fileName)
        {
            StreamReader fp = new StreamReader(fileName);
            string record;
            int row = 0;
            while ((record = fp.ReadLine()) != null)
            {
                for (int x = 0; x < 53; x++)
                {
                    GameCell cell = new GameCell(row, x, this);
                    char character = record[x];
                    GameObjectType type = GameObject.GetGameObjectType(character);
                    Image displayimage = Game.GetGameObjectImage(character);
                    GameObject obj = new GameObject( GameObject.GetGameObjectType(character), displayimage);
                    cell.SetGameObject(obj);
                    GameCells[row, x] = cell;
                }
                row++;
            }

            fp.Close();

        }
        public GameCell getCell(int row, int col) 
        {
            return GameCells[row, col];
        }
        public static double Get_Distance(GameCell cell1, GameCell cell2)
        {
            return Math.Sqrt(Math.Pow(cell2.x - cell1.x, 2) + Math.Pow(cell2.y - cell1.y, 2));
        }
        public int Rows { get => rows; set => rows = value; }
        public int Columns { get => cols; set => cols = value; }
    }
}
