﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SnowBrosGame
{
    class GameCell
    {
        public int x;
        public int y;
        public GameObject currentGameObject;
        public GameGrid gameGrid; 
        public PictureBox pictureBox;
        const int width = 20;
        const int height = 20;
        public GameCell(int x, int y, GameGrid gameGrid)
        {
            this.x = x;
            this.y = y;
            pictureBox = new PictureBox();
            pictureBox.Left = y * width; 
            pictureBox.Top = x * height;
            pictureBox.Size = new Size(width, height);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.BackColor = Color.Transparent;
            this.gameGrid = gameGrid;
        }
        public GameCell()
        {

        }
        public void SetGameObject(GameObject gameObject)
        {
            currentGameObject = gameObject;
            pictureBox.Image = gameObject.Image;

        }
        public GameCell NextCell(GameDirection direction)
        {
            if (direction == GameDirection.UP)
            {
                if (this.X > 0)
                {
                    GameCell cell = gameGrid.getCell(this.X - 1, this.Y);
                    if (cell.currentGameObject.gameObjectType != GameObjectType.WALL)
                    {
                        return cell;
                    }
                }
            }
            if (direction == GameDirection.DOWN)
            {
                if (this.X < gameGrid.rows - 1)
                {
                    GameCell cell = gameGrid.getCell(this.X + 1, this.Y);
                    if (cell.currentGameObject.gameObjectType != GameObjectType.WALL)
                    {
                        return cell;
                    }
                }

            }
            if (direction == GameDirection.RIGHT)
            {
                if (this.Y < gameGrid.cols - 1)
                {
                    GameCell cell = gameGrid.getCell(this.X, this.Y + 1);
                    if (cell.currentGameObject.gameObjectType != GameObjectType.WALL)
                    {
                        return cell;
                    }
                }

            }
            if (direction == GameDirection.LEFT)
            {
                if (this.Y > 0)
                {
                    GameCell cell = gameGrid.getCell(this.X, this.Y - 1);
                    if (cell.currentGameObject.gameObjectType != GameObjectType.WALL)
                    {
                        return cell;
                    }
                }
            }
            return gameGrid.GameCells[X, Y];
        }
        public int X { get => x; set => x = value; }
        public int Y { get => y; set => y = value; }
        public GameObject CurrentGameObject { get => currentGameObject; }
        public PictureBox PictureBox { get => pictureBox; set => pictureBox = value; }


    }
}
