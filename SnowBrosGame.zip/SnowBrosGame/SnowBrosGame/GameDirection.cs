﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnowBrosGame
{
    public enum GameDirection
    {
        LEFT,
        UP,
        RIGHT,
        DOWN,
    }
}
