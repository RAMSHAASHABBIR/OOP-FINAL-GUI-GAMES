﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
    class HorizontalGhost : Ghost
    {
        GameDirection direction;
        public HorizontalGhost(Image image, GameCell CurrentCell, GameDirection direction) : base(GameObjectType.ENEMY, image)
        {
            this.direction = direction;
            this.CurrentCell = CurrentCell;
        }
        public override GameCell Move()
        {
           if (previousObject== GameObjectType.REWARD)
            {
                CurrentCell.SetGameObject(Game.GetRewardGameObject());
            }
            else if (previousObject== GameObjectType.NONE)
            {
                CurrentCell.SetGameObject(Game.GetBlankGameObject());
            }
            GameCell currentCell = CurrentCell;
            GameCell nextCell = currentCell.NextCell(direction);
			if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.REWARD)
			{
				previousObject = GameObjectType.REWARD;
			}
			else if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.NONE)
			{
				previousObject = GameObjectType.NONE;
			}
			CurrentCell = nextCell;
			if (nextCell == currentCell)
            {
                if (direction == GameDirection.RIGHT)
                    direction = GameDirection.LEFT;
                else
                    direction = GameDirection.RIGHT;
                this.Move();
			}

			return nextCell;
        }
    }
}
