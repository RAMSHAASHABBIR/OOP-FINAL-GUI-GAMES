﻿using SnowBrosGame.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnowBrosGame
{
     class Game
    {
        public static Image GetGameObjectImage(char displayCharacter)
        {
            Image img = SnowBrosGame.Properties.Resources.simplebox;
            if (displayCharacter == '|' || displayCharacter == '%')
                img = SnowBrosGame.Properties.Resources.Vertical_grid;
            if (displayCharacter == '#')
                img = SnowBrosGame.Properties.Resources.Horizontal_grid;
            if (displayCharacter == '.')
                img = SnowBrosGame.Properties.Resources.Pallets;
            if (displayCharacter == 'P' || displayCharacter == 'p')
                img = SnowBrosGame.Properties.Resources.Hero_red;
            if (displayCharacter == 'H' || displayCharacter == 'h')
                img = SnowBrosGame.Properties.Resources.Ghost_smiley;
            if (displayCharacter == 'V' || displayCharacter == 'v')
                img = SnowBrosGame.Properties.Resources.Ghost_green;
            if (displayCharacter == 'R' || displayCharacter == 'r')
                img = SnowBrosGame.Properties.Resources.Ghost_random;
            if (displayCharacter == 'S' || displayCharacter == 's')
                img = SnowBrosGame.Properties.Resources.Ghost_orange;

            return img;
        }
        public static GameObject GetBlankGameObject()
        {
            GameObject blankGameObject = new GameObject(GameObjectType.NONE,SnowBrosGame.Properties.Resources.simplebox);
            return blankGameObject;
        }
        public static GameObject GetRewardGameObject()
        {
            GameObject RewardObject = new GameObject(GameObjectType.REWARD,Resources.Pallets);
            return RewardObject;
        }
    }
}
