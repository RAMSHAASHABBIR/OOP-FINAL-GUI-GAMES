﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
    class SnowBrosPlayer : GameObject
    {
        public static int score;
        public static int decreasehealth = 5;
        public SnowBrosPlayer(Image DisplayImage, GameCell CurrentCell) : base(GameObjectType.PLAYER, DisplayImage)
        {
            this.CurrentCell = CurrentCell;
        }
        public GameCell move(GameDirection direction)  
        {

            GameCell currentcell = this.CurrentCell;

            GameCell nextcell = currentcell.NextCell(direction);
            bool check = Collisions.PlayerCollisionWithPallet(nextcell);
            if (Collisions.PlayerCollisionWithPallet(nextcell))
            {
                score++;
            }
            if (nextcell == null)
                return null;
            nextcell.SetGameObject(this);
            this.CurrentCell = nextcell;
            if (currentcell != nextcell)
            {
                currentcell.SetGameObject(Game.GetBlankGameObject());
            }
            return nextcell;
           
        }
    }
}
