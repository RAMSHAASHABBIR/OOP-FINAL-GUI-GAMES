﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace SnowBrosGame
{
     class VerticalGhost : Ghost
    {
        GameDirection direction;
        public VerticalGhost(Image image, GameCell CurentCell, GameDirection direction) : base(GameObjectType.ENEMY, image)
        {
            this.direction = direction;
            this.CurrentCell = CurentCell;
        }
        public override GameCell Move()
        {
            if (previousObject == GameObjectType.REWARD)
            {
                CurrentCell.SetGameObject(Game.GetRewardGameObject());
            }
            else if (previousObject == GameObjectType.NONE)
            {
                CurrentCell.SetGameObject(Game.GetBlankGameObject());
            }
            GameCell currentCell = CurrentCell;
            GameCell nextCell = currentCell.NextCell(direction);
            if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.REWARD)
            {
                previousObject = GameObjectType.REWARD;
            }
            else if (nextCell.CurrentGameObject.gameObjectType == GameObjectType.NONE)
            {
                previousObject = GameObjectType.NONE;
            }
            CurrentCell = nextCell;
            if (nextCell == currentCell)
            {
                if (direction == GameDirection.UP)
                    direction = GameDirection.DOWN;
                else
                    direction = GameDirection.UP;
                this.Move();
            }
            return nextCell;
        }
    }
}
