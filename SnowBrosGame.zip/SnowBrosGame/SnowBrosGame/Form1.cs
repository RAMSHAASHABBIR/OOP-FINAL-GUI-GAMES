﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EZInput;

namespace SnowBrosGame
{
    public partial class Form1 : Form
    {
        GameCell startcell;
        SnowBrosPlayer player;
        HorizontalGhost Hghost;
        GameCell ghostHCell;
        HorizontalGhost Hghost1;
        GameCell ghostHCell1;
        VerticalGhost Vghost;
        GameCell ghostVCell;
        VerticalGhost Vghost1;
        GameCell ghostVCell1;
        VerticalGhost Vghost2;
        GameCell ghostVCell2;
        RandomGhost Rghost;
        GameCell ghostRCell; 
        RandomGhost Rghost1;
        GameCell ghostRCell1;
        RandomGhost Rghost2;
        GameCell ghostRCell2;
        SmartGhost SGhost;
        GameCell ghostSCell;
        GameGrid grid;
        List<Ghost> enemy = new List<Ghost>();
        List<Shooting> bullets = new List<Shooting>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            grid = new GameGrid("snow-maze.txt", 25, 53);
            PrintMaze(grid);

            Image pacManImage = Game.GetGameObjectImage('P');
             startcell = grid.getCell(10, 18); 
            player = new SnowBrosPlayer(pacManImage, startcell );

            Image HorizontalImage = Game.GetGameObjectImage('H');
            ghostHCell = grid.getCell(18,18);
            Hghost = new HorizontalGhost(HorizontalImage, ghostHCell, GameDirection.RIGHT);
            enemy.Add(Hghost);

            Image HorizontalImage1 = Game.GetGameObjectImage('H'); 
            ghostHCell1 = grid.getCell(8, 18);
            Hghost1 = new HorizontalGhost(HorizontalImage1, ghostHCell1, GameDirection.RIGHT);
            enemy.Add(Hghost1);  

            Image VerticalImage = Game.GetGameObjectImage('V');
            ghostVCell = grid.getCell(10,35);
            Vghost = new VerticalGhost(VerticalImage, ghostVCell, GameDirection.RIGHT);
            enemy.Add(Vghost);

            Image VerticalImage1 = Game.GetGameObjectImage('V');
            ghostVCell1 = grid.getCell(10, 22);
            Vghost1 = new VerticalGhost(VerticalImage1, ghostVCell1, GameDirection.RIGHT);
            enemy.Add(Vghost1);
             
            Image VerticalImage2 = Game.GetGameObjectImage('V');
            ghostVCell2 = grid.getCell(8, 45);
            Vghost2 = new VerticalGhost(VerticalImage2, ghostVCell2, GameDirection.RIGHT);
            enemy.Add(Vghost2);

            Image RandomImage = Game.GetGameObjectImage('R');
            ghostRCell = grid.getCell(19, 32);
            Rghost = new RandomGhost(RandomImage, ghostRCell);
            enemy.Add(Rghost);

            Image RandomImage1 = Game.GetGameObjectImage('R');
            ghostRCell1 = grid.getCell(4, 6);
            Rghost1 = new RandomGhost(RandomImage1, ghostRCell1);
            enemy.Add(Rghost1);

            Image RandomImage2 = Game.GetGameObjectImage('R');
            ghostRCell2 = grid.getCell(10, 50);
            Rghost2 = new RandomGhost(RandomImage2, ghostRCell2);
            enemy.Add(Rghost2); 

            Image SmartImage = Game.GetGameObjectImage('S');
            ghostSCell = grid.getCell(15,13);
            SGhost = new SmartGhost(SmartImage, ghostSCell,player);
            enemy.Add(SGhost);
        }
        private void PrintMaze (GameGrid grid )
        {
            for (int x = 0; x < grid.Rows; x++)
            {
                for (int y = 0; y < grid.Columns; y++)
                {
                    GameCell cell = grid.getCell(x, y);
                    Controls.Add(cell.PictureBox);
                }
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
             foreach(var ghost in enemy)
             {
                 ghost.Move(); 
             }
           
            generatebullets();
            foreach (var bullet in bullets)
            {
                string x = bullet.move();
				if (x=="W")
                {
                    bullets.Remove(bullet); 
                    break;
                }
				if (x == "E")
				{
                    foreach(Ghost ghost in enemy)
                    {
                        if(Collisions.PlayerCollisionWithGhost(bullet, ghost))
                        {
                            enemy.Remove(ghost);
                            Ghost.ghostdecreasehealth--;
                            txtenemycount.Visible = true;
                            txtenemycount.Text = Ghost.ghostdecreasehealth.ToString();
                            break;
                        }
                    }
					bullets.Remove(bullet); 
                    break;
				}
                if (Ghost.ghostdecreasehealth == 0 || Ghost.ghostdecreasehealth < 0)
                {
                    GameTimer.Enabled = false;
                    FormGameWon formGameWon = new FormGameWon();
                    Form1 form1 = new Form1();
                    form1.Hide();
                    formGameWon.Show();
                }
            
            }
            if (player == null) return;
            if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                player.move(GameDirection.LEFT);
            }
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                player.move(GameDirection.RIGHT);
            }
            if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                player.move(GameDirection.UP);
            }
            if (Keyboard.IsKeyPressed(Key.DownArrow))
            {
                player.move(GameDirection.DOWN);
            }
            GameCell g = new GameCell();
            if (Collisions.PlayerCollisionWithPallet(g))
            {
                SnowBrosPlayer.score++;
            }
           
            TxtPrintScore.Visible = true;
            TxtPrintScore.Text = SnowBrosPlayer.score.ToString();
            GameCell g1 = new GameCell();
            if (Collisions.PlayerCollisionWithGhost(g1))
            {
                SnowBrosPlayer.decreasehealth--;
            }
            if (Collisions.PlayerCollisionWithGhost(player,Hghost) ||
                Collisions.PlayerCollisionWithGhost(player, Vghost) ||
                Collisions.PlayerCollisionWithGhost(player, Rghost) ||
                Collisions.PlayerCollisionWithGhost(player, SGhost) ||
                Collisions.PlayerCollisionWithGhost(player, Rghost1) ||
                Collisions.PlayerCollisionWithGhost(player, Rghost2) ||
                Collisions.PlayerCollisionWithGhost(player, Vghost1) ||
                Collisions.PlayerCollisionWithGhost(player, Hghost1) ||
                Collisions.PlayerCollisionWithGhost(player, Vghost2))
            {
                SnowBrosPlayer.decreasehealth--; 
                player.image = null;
                Image pacManImage = Game.GetGameObjectImage('P');
                startcell = grid.getCell(10, 18);
                player = new SnowBrosPlayer(pacManImage,startcell);
                SGhost.snowbros = player;
              
            } 
            if (SnowBrosPlayer.decreasehealth == 0)
            {
                GameTimer.Enabled = false;
               FormEndGame formEndGame = new FormEndGame();
                Form1 form1 = new Form1();
                form1.Hide();
                formEndGame.Show();
            }
            TxtPrintLives.Visible = true;
            TxtPrintLives.Text = SnowBrosPlayer.decreasehealth.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void generatebullets()
        {
            if (Keyboard.IsKeyPressed(Key.V))
            {
                Image bulletimage = Properties.Resources.ball;
                Shooting shooting = new Shooting(bulletimage, player.CurrentCell.NextCell(GameDirection.LEFT), GameDirection.LEFT);
                shooting.CurrentCell = player.CurrentCell.NextCell(GameDirection.LEFT);
                bullets.Add(shooting);
            }
            if (Keyboard.IsKeyPressed(Key.B))
            {
                Image bulletimage = Properties.Resources.ball;
                Shooting shooting = new Shooting(bulletimage, player.CurrentCell.NextCell(GameDirection.UP), GameDirection.UP);
                shooting.CurrentCell = player.CurrentCell.NextCell(GameDirection.UP);
                bullets.Add(shooting);
            }
            if (Keyboard.IsKeyPressed(Key.N))
            {
                Image bulletimage = Properties.Resources.ball;
                Shooting shooting = new Shooting(bulletimage, player.CurrentCell.NextCell(GameDirection.DOWN), GameDirection.DOWN);
                shooting.CurrentCell = player.CurrentCell.NextCell(GameDirection.DOWN);
                bullets.Add(shooting);
            }
            if (Keyboard.IsKeyPressed(Key.M))
            {
                Image bulletimage = Properties.Resources.ball;
                Shooting shooting = new Shooting(bulletimage, player.CurrentCell.NextCell(GameDirection.RIGHT), GameDirection.RIGHT);
                shooting.CurrentCell = player.CurrentCell.NextCell(GameDirection.RIGHT);
                bullets.Add(shooting);
            }
        }

        private void TxtScore_Click(object sender, EventArgs e)
        {

        }
    }
}
