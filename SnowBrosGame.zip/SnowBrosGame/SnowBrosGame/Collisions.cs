﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnowBrosGame
{
     class Collisions
    {
        public static bool PlayerCollisionWithPallet(GameCell nextCell)
        {
            if (nextCell == null)
            {
                return false;
            }
            if (nextCell.currentGameObject == null)
            {
                return false;
            }
            if (nextCell.currentGameObject.gameObjectType == GameObjectType.REWARD)
            {
                return true;
            }
            return false;
        }
        public static bool PlayerCollisionWithGhost(GameCell nextCell)
        {
            if (nextCell == null)
            {
                return false;
            }
            if (nextCell.currentGameObject == null)
            {
                return false;
            }
            if (nextCell.currentGameObject.gameObjectType == GameObjectType.ENEMY)
            {

                return true;

            }

            return false;
        }
        public static bool PlayerCollisionWithGhost(GameObject obj1, GameObject obj2)
        {
            if (obj1.CurrentCell.X == obj2.CurrentCell.X && obj1.CurrentCell.Y == obj2.CurrentCell.Y)
            {

                return true;

            }

            return false;
        }
    }
}
